<!-- <div class="client-area ptb-115" style="padding-top: 0">
	<div class="container">
		<div class="row">
			<div class="client-carousel carousel-none">
				<div class="col-xs-12">
					<div class="single-client block pt-7 pb-7">
						<a href="index.html#" class="block">
							<span><img src="images/client/1.png" alt=""></span>
						</a>
					</div>
				</div>
				<div class="col-xs-12">
					<div class="single-client block pt-7 pb-7">
						<a href="index.html#" class="block">
							<span><img src="images/client/2.png" alt=""></span>
						</a>
					</div>
				</div>
				<div class="col-xs-12">
					<div class="single-client block pt-7 pb-7">
						<a href="index.html#" class="block">
							<span><img src="images/client/3.png" alt=""></span>
						</a>
					</div>
				</div>
				<div class="col-xs-12">
					<div class="single-client block pt-7 pb-7">
						<a href="index.html#" class="block">
							<span><img src="images/client/4.png" alt=""></span>
						</a>
					</div>
				</div>
				<div class="col-xs-12">
					<div class="single-client block pt-7 pb-7">
						<a href="index.html#" class="block">
							<span><img src="images/client/5.png" alt=""></span>
						</a>
					</div>
				</div>
			</div>	
		</div>
	</div>
</div> -->