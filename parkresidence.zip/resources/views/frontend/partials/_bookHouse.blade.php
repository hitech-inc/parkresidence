<div class="advertise-area bg-1 bg-overlay-1 pt-76 pb-76 wow fadeInUp">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h1 class="text-white mb-22">Спешите забронировать виллу своей мечты!</h1>
				<h2 class="text-white">Подробнее по телефону : +7 701 9117744 </h2>
			</div>
		</div>
	</div>
</div>