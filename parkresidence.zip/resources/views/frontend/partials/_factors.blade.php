<div class="container">
  <div class="row">
    <div class="col-md-3 col-sm-3">
        <div class="single-fun-factor">
           <div class="text-icon mb-8 block">
              <img src="images/icons/home.png" alt="" class="mr-15">
              <h2><span class="counter">999</span></h2>
          </div>
          <h4>Количество домов</h4>
      </div>
  </div>
  <div class="col-md-3 col-sm-3">
    <div class="single-fun-factor">
       <div class="text-icon mb-8 block">
          <img src="images/icons/key.png" alt="" class="mr-15">
          <h2><span class="counter">720</span></h2>
      </div>
      <h4>Продано</h4>
  </div>
</div>
<div class="col-md-3 col-sm-3">
    <div class="single-fun-factor">
       <div class="text-icon mb-8 block">
          <img src="images/icons/face.png" alt="" class="mr-15">
          <h2><span class="counter">750</span></h2>
      </div>
      <h4>Счастливые клиенты</h4>
  </div>
</div>
<div class="col-md-3 col-sm-3">
    <div class="single-fun-factor">
       <div class="text-icon mb-8 block">
          <img src="images/icons/trophy.png" alt="" class="mr-15">
          <h2><span class="counter">120</span></h2>
      </div>
      <h4>Награды</h4>
  </div>
</div>
</div>
</div>