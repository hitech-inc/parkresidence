<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Сообщение с сайта www.parkresidence.kz</title>
</head>
<body>
	<h1>Новое сообщение с сайта: <a href="http://parkresidence.kz">www.parkresidence.kz</a></h1>
	<p>Имя отправителя: {{ $name }}</p>
	<p>Email: {{ $email }}</p>
	<p>Сообщение: {{ $text }}</p>
</body>
</html>