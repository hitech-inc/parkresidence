
<li class="{{ Request::is('houses*') ? 'active' : '' }}">
    <a href="{!! route('backend.houses.index') !!}"><i class="fa fa-edit"></i><span>Houses</span></a>
</li>

