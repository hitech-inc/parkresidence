<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Сообщение с сайта www.parkresidence.kz</title>
</head>
<body>
	<h1>Новое сообщение с сайта: <a href="http://parkresidence.kz">www.parkresidence.kz</a></h1>
	<p>Имя отправителя: <?php echo e($name); ?></p>
	<p>Email: <?php echo e($email); ?></p>
	<p>Сообщение: <?php echo e($text); ?></p>
</body>
</html>