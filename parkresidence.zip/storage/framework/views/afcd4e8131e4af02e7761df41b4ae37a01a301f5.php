<div id="sticky-header">
	<div class="container">
		<div class="row">
			<div class="col-md-2 col-xs-12">
				<div class="logo"><a href="/"><img src="/images/logo/logo3.1.png" alt="DomInno"></a></div>
			</div>
			<div class="col-md-10 hidden-sm hidden-xs">
				<div class="pull_right">
					<nav id="primary-menu" class="height-large">              
						<ul class="main-menu text-left">
							<li class="mega-parent active"><a href="/">Главная</a>

							</li>
							<li><a href="/about">О Park residence</a>

							</li>
							<li><a href="/location">Расположение</a>

							</li>
							<li class="mega-parent"><a href="/town-houses">Таунхаусы</a>

							</li>
							<li class="mega-parent"><a href="/villas">Виллы</a>

							</li>

							<li><a href="/contacts">Контакты</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Mobile Menu Area start -->
<div class="mobile-menu-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="mobile-menu">
					<nav id="dropdown">
						<ul>
							<li><a href="/">Главная<a>
							</li>
							<li><a href="/about">O Park residence</a>
							</li>
							<li><a href="/features">Особенности</a>
								
							</li>
							<li><a href="/cottages">Котеджи</a>
								
							</li>
							<li><a href="/3D-tour">3D тур</a>
								
							</li>
							<li><a href="/contacts">Контакты</a></li>
						</ul>
					</nav>
				</div>					
			</div>
		</div>
	</div>
</div>
<!-- Mobile Menu Area end --> 