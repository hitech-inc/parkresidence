<div class="testimonial-area text-center fix pt-100 pb-115">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title mb-40 mt-31 text-center">
					<span class="opacity-text text-uppercase center">Комментарии клиентов</span>
					<h2 class="uppercase mb-25">Счастливые клиенты</h2>
					<p class="pb-15">Park residence is the best theme for  elit, sed do eiusmod tempor dolor sit amet, conse ctetur adipiscing elit, sed<br> do eiusmod tempor incididunt ut labore et lorna aliquatd minim veniam, quis nostrud exercitation oris</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="testimonial-image-slider text-center">
					<div class="sin-div">
						<div class="sin-testiImage">
							<img src="images/testimonial/2.jpg" alt="testimonial 1" />
						</div>
						<div class="sin-testiText">
							<p><span>Park residence</span> is the best theme for  elit, sed do od tempor dolor sit amet, conse tetur adipiscingit, ed do eiusm label</p>
							<h4>Алтай, <span>CEO</span></h4>
						</div>
					</div>
					<div class="sin-div">
						<div class="sin-testiImage">
							<img src="images/testimonial/3.jpg" alt="testimonial 2" />
						</div>
						<div class="sin-testiText">
							<p><span>Park residence</span> is the best theme for  elit, sed do od tempor dolor sit amet, conse tetur adipiscingit, ed do eiusm label</p>
							<h4>Балтабай, <span>CEO</span></h4>
						</div>
					</div>
					<div class="sin-div">
						<div class="sin-testiImage">
							<img src="images/testimonial/1.jpg" alt="testimonial 3" />
						</div>
						<div class="sin-testiText">
							<p><span>Park residence</span> is the best theme for  elit, sed do od tempor dolor sit amet, conse tetur adipiscingit, ed do eiusm label</p>
							<h4>Жазира, <span>CEO</span></h4>
						</div>
					</div>
					<div class="sin-div">
						<div class="sin-testiImage">
							<img src="images/testimonial/3.jpg" alt="testimonial 1" />
						</div>
						<div class="sin-testiText">
							<p><span>Park residence</span> is the best theme for  elit, sed do od tempor dolor sit amet, conse tetur adipiscingit, ed do eiusm label</p>
							<h4>Алтай, <span>CEO</span></h4>
						</div>
					</div>
					<div class="sin-div">
						<div class="sin-testiImage">
							<img src="images/testimonial/2.jpg" alt="testimonial 2" />
						</div>
						<div class="sin-testiText">
							<p><span>Park residence</span> is the best theme for  elit, sed do od tempor dolor sit amet, conse tetur adipiscingit, ed do eiusm label</p>
							<h4>Балтабай, <span>CEO</span></h4>
						</div>
					</div>
					<div class="sin-div">
						<div class="sin-testiImage">
							<img src="images/testimonial/1.jpg" alt="testimonial 3" />
						</div>
						<div class="sin-testiText">
							<p><span>Park residence</span> is the best theme for  elit, sed do od tempor dolor sit amet, conse tetur adipiscingit, ed do eiusm label</p>
							<h4>Жазира, <span>CEO</span></h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>