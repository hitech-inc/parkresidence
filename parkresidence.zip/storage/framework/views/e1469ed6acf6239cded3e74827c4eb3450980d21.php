
<li class="<?php echo e(Request::is('houses*') ? 'active' : ''); ?>">
    <a href="<?php echo route('backend.houses.index'); ?>"><i class="fa fa-edit"></i><span>Houses</span></a>
</li>

